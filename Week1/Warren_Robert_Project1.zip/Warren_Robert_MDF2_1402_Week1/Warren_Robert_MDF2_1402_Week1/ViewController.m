//
//  ViewController.m
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/3/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import "ViewController.h"
#import "TwitCell.h"
#import <Accounts/Accounts.h>
#import <Social/Social.h>
#import "SecondViewController.h"
#import "ThirdViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    //custom nib for my reusable cells
    UINib *TwitCellNib = [UINib nibWithNibName:@"TwitCell" bundle:nil];
    if (TwitCellNib != nil)
    {
        [tabled registerNib:TwitCellNib forCellReuseIdentifier:@"TwitCell"];
    }
    
    //call on twitter feed on initial launch
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,
    ^{
        [self fetchTweets];
    });

    [super viewDidLoad];
    
    //set row height
    self->tabled.rowHeight = 100.f;
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)viewDidAppear:(BOOL)animated
{
    // resets selected cells to none selected
    [tabled reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// the actual call to twitter reusable method
-(void)fetchTweets
{
    ACAccountStore *ACStore = [[ACAccountStore alloc] init];
    
    if (ACStore != nil)
    {
        

        
        ACAccountType *ACType =[ACStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
        if (ACType != nil)
        {
            alert = [[UIAlertView alloc] initWithTitle:@"Loading Tweets"
                                               message:@"\n"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:nil];
            [alert show];

            [ACStore requestAccessToAccountsWithType:ACType options:nil completion:^(BOOL granted, NSError *error)
             {
                 NSArray *twitAcc = [ACStore accountsWithAccountType:ACType];
                 if (twitAcc != nil)
                 {
                     ACAccount *currAcc = [twitAcc objectAtIndex:0];
                     if (currAcc != nil)
                     {
                         NSString *userTimeStr = @"https://api.twitter.com/1.1/statuses/user_timeline.json?count=20";
                         
                         SLRequest *req = [SLRequest requestForServiceType:SLServiceTypeTwitter requestMethod:SLRequestMethodGET URL:[NSURL URLWithString:userTimeStr] parameters:nil];
                         if (req != nil)
                         {
                             [req setAccount:currAcc];
                             
                             [req performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) {
                                 NSInteger rCode = [urlResponse statusCode];
                                 if (rCode == 200)
                                 {
                                     feeder = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
                                     if (feeder != nil)
                                     {
                                         [tabled reloadData];
                                         
                                         
                                         
                                     }
                                 }
                             }];
                         }
                     }
                     // NSLog(@"%@", [twitAcc description]);
                 }
             }];
        }
    }
    
    
}

// set tableview number of cells
- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    if (feeder != nil)
    {
        return [feeder count];
    }
    return 0;
}


//create tags and insert data
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TwitCell *cell = [tabled dequeueReusableCellWithIdentifier:@"TwitCell"];
    if (cell != nil)
    {
        NSDictionary *twitDict = [feeder objectAtIndex:indexPath.row];
        NSDictionary *userDict = [twitDict objectForKey:@"user"];
       // NSLo
        
        cell.tText = [twitDict valueForKey:@"text"];
        cell.tDate = [twitDict valueForKey:@"created_at"];
        NSData *image = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[userDict valueForKey:@"profile_image_url_https"]]];
        cell.tImage = [[UIImage alloc] initWithData:image];
        
        [cell loadCell];
        [alert dismissWithClickedButtonIndex:0 animated:YES];
        return cell;
    }
    return nil;
}

//create cells
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary *twitDict = [feeder objectAtIndex:indexPath.row];
    NSDictionary *userDict = [twitDict objectForKey:@"user"];
    
    
    twitText = [twitDict valueForKey:@"text"];
    twitDate = [twitDict valueForKey:@"created_at"];
    twitUser = [userDict valueForKey:@"screen_name"];
    
    
    [self performSegueWithIdentifier: @"detail" sender: self];
}

// post new twits to actual twitter feed
-(IBAction)poster:(id)sender
{
    SLComposeViewController *composer = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    if (composer != nil)
    {
        [composer setInitialText:@"Posted From Robert Warren's MDF2 Week 1 Project.... Hello World"];
        
        [self presentViewController:composer animated:true completion:nil];
        
    }
}

// refresh feed by calling reusable method
-(IBAction)onRefresh:(id)sender
{
    [self fetchTweets];
}

//send data to profile view
-(IBAction)Prolific:(id)sender
{
    NSDictionary *twitDict = [feeder objectAtIndex:1];
    NSDictionary *userDict = [twitDict objectForKey:@"user"];
    
    
    twitName = [userDict valueForKey:@"name"];
    twitUser = [userDict valueForKey:@"screen_name"];
    twitDetail = [userDict valueForKey:@"description"];
    twitFollowed = [userDict valueForKey:@"followers_count"];
    twitFriends = [userDict valueForKey:@"friends_count"];
    NSData *image = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[userDict valueForKey:@"profile_image_url_https"]]];
    twitImage = [[UIImage alloc] initWithData:image];
    
    
    [self performSegueWithIdentifier: @"profile" sender: self];
}

//prepare for segue for both additional views
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    //sends if to twit detail page
    if ([segue.identifier isEqualToString:@"detail"])
    {
        SecondViewController *destination = segue.destinationViewController;
        destination.insertTwit = twitText;
        destination.insertDate = twitDate;
        destination.insertUser = twitUser;
    }
    //sends inf to profile view
    else if ([segue.identifier isEqualToString:@"profile"])
    {
        ThirdViewController *destination = segue.destinationViewController;
        destination.insertName = twitName;
        destination.insertUser = twitUser;
        destination.insertdetail = twitDetail;
        destination.insertFollowers = twitFollowed;
        destination.insertFriends = twitFriends;
        destination.insertImage = twitImage;
    }
}


@end
