//
//  TwitCell.h
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/4/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TwitCell : UITableViewCell
{
    //outlets
    IBOutlet UILabel *feedText;
    IBOutlet UILabel *feedDate;
    IBOutlet UIImageView *feedImage;
}

//method
-(void)loadCell;

//properties
@property (nonatomic, strong) NSString *tText;
@property (nonatomic, strong) NSString *tDate;
@property (nonatomic, strong) UIImage *tImage;

@end
