//
//  TwitCell.m
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/4/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import "TwitCell.h"

@implementation TwitCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)loadCell
{
    //assign outlets with info
    feedText.text = _tText;
    feedDate.text = _tDate;
    feedImage.image = _tImage;
   // NSLog(@"%@", _tImage);
}

@end
