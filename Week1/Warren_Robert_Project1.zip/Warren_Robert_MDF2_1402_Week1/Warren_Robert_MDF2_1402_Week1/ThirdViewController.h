//
//  ThirdViewController.h
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/4/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import "ViewController.h"

@interface ThirdViewController : ViewController
{
    //outlets
    IBOutlet UILabel *pName;
    IBOutlet UILabel *pUser;
    IBOutlet UILabel *pDetail;
    IBOutlet UILabel *pFollower;
    IBOutlet UILabel *pFriend;
    IBOutlet UIImageView *Propic;
}

//properties
@property (strong, nonatomic) NSString *insertName;
@property (strong, nonatomic) NSString *insertUser;
@property (strong, nonatomic) NSString *insertdetail;
@property (strong, nonatomic) NSString *insertFollowers;
@property (strong, nonatomic) NSString *insertFriends;
@property (strong, nonatomic) UIImage *insertImage;

//method for button
-(IBAction)back:(id)sender;

@end
