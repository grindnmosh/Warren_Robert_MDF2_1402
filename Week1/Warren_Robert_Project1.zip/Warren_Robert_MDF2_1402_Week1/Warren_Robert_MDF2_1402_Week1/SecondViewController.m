//
//  SecondViewController.m
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/4/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    //assign outlets with info
    self->tweets.text = _insertTwit;
    self->date.text = _insertDate;
    self->user.text = _insertUser;
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//back to main view
-(IBAction)back:(id)sender
{
    //close
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
