//
//  AppDelegate.h
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/3/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
