//
//  SecondViewController.h
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/4/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import "ViewController.h"

@interface SecondViewController : ViewController
{
    //outlets
    IBOutlet UILabel *tweets;
    IBOutlet UILabel *date;
    IBOutlet UILabel *user;
}

//properties
@property (strong, nonatomic) NSString *insertTwit;
@property (strong, nonatomic) NSString *insertDate;
@property (strong, nonatomic) NSString *insertUser;

//method for button
-(IBAction)back:(id)sender;

@end
