//
//  ViewController.m
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/3/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import "ViewController.h"
#import "TwitCell.h"
#import <Accounts/Accounts.h>
#import <Social/Social.h>
#import "SecondViewController.h"
#import "ThirdViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    
    UINib *TwitCellNib = [UINib nibWithNibName:@"TwitCell" bundle:nil];
    if (TwitCellNib != nil)
    {
        [tabled registerNib:TwitCellNib forCellReuseIdentifier:@"TwitCell"];
    }
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,
    ^{
        [self fetchTweets];
    });

    [super viewDidLoad];

    self->tabled.rowHeight = 100.f;
	// Do any additional setup after loading the view, typically from a nib.
    //[self fetchTweets];
}

-(void)viewDidAppear:(BOOL)animated
{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)fetchTweets
{
    ACAccountStore *ACStore = [[ACAccountStore alloc] init];
    
    if (ACStore != nil)
    {
        

        
        ACAccountType *ACType =[ACStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
        if (ACType != nil)
        {
            alert = [[UIAlertView alloc] initWithTitle:@"Loading Tweets"
                                               message:@"\n"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:nil];
            indicator = [[UIActivityIndicatorView alloc]
                         initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            indicator.center = CGPointMake(400, 480);
            indicator.hidesWhenStopped = YES;
            [self.view addSubview:indicator];
            [indicator startAnimating];
            [alert show];
            [ACStore requestAccessToAccountsWithType:ACType options:nil completion:^(BOOL granted, NSError *error)
             {
                 NSArray *twitAcc = [ACStore accountsWithAccountType:ACType];
                 if (twitAcc != nil)
                 {
                     ACAccount *currAcc = [twitAcc objectAtIndex:0];
                     if (currAcc != nil)
                     {
                         NSString *userTimeStr = [NSString stringWithFormat:@"%@?%@&%@", @"https://api.twitter.com/1.1/statuses/user_timeline.json", @"screen_name=grindnmosh", @"count=20"];
                         
                         SLRequest *req = [SLRequest requestForServiceType:SLServiceTypeTwitter requestMethod:SLRequestMethodGET URL:[NSURL URLWithString:userTimeStr] parameters:nil];
                         if (req != nil)
                         {
                             [req setAccount:currAcc];
                             
                             [req performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) {
                                 NSInteger rCode = [urlResponse statusCode];
                                 if (rCode == 200)
                                 {
                                     feeder = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
                                     if (feeder != nil)
                                     {
                                         [tabled reloadData];
                                         [indicator stopAnimating];
                                         [alert dismissWithClickedButtonIndex:0 animated:YES];
                                         
                                     }
                                 }
                             }];
                         }
                     }
                     // NSLog(@"%@", [twitAcc description]);
                 }
             }];
        }
    }
    
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    if (feeder != nil)
    {
        return [feeder count];
    }
    return 0;
}


//create tags and insert data
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TwitCell *cell = [tabled dequeueReusableCellWithIdentifier:@"TwitCell"];
    if (cell != nil)
    {
        NSDictionary *twitDict = [feeder objectAtIndex:indexPath.row];
        NSDictionary *userDict = [twitDict objectForKey:@"user"];
       // NSLo
        
        cell.tText = [twitDict valueForKey:@"text"];
        cell.tDate = [twitDict valueForKey:@"created_at"];
        NSData *image = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[userDict valueForKey:@"profile_image_url_https"]]];
        cell.tImage = [[UIImage alloc] initWithData:image];
        
        [cell loadCell];
        return cell;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary *twitDict = [feeder objectAtIndex:indexPath.row];
    NSDictionary *userDict = [twitDict objectForKey:@"user"];
    
    
    twitText = [twitDict valueForKey:@"text"];
    twitDate = [twitDict valueForKey:@"created_at"];
    twitUser = [userDict valueForKey:@"screen_name"];
    
    
    [self performSegueWithIdentifier: @"detail" sender: self];
}


-(IBAction)poster:(id)sender
{
    SLComposeViewController *composer = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    if (composer != nil)
    {
        [composer setInitialText:@"Posted From Robert Warren's MDF2 Week 1 Project.... Hello World"];
        
        [self presentViewController:composer animated:true completion:nil];
        
    }
}




-(IBAction)onRefresh:(id)sender
{
    [self fetchTweets];
}

-(IBAction)Prolific:(id)sender
{
    NSDictionary *twitDict = [feeder objectAtIndex:1];
    NSDictionary *userDict = [twitDict objectForKey:@"user"];
    
    
    twitName = [userDict valueForKey:@"name"];
    twitUser = [userDict valueForKey:@"screen_name"];
    twitDetail = [userDict valueForKey:@"description"];
    twitFollowed = [userDict valueForKey:@"followers_count"];
    twitFriends = [userDict valueForKey:@"friends_count"];
    NSData *image = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[userDict valueForKey:@"profile_image_url_https"]]];
    twitImage = [[UIImage alloc] initWithData:image];
    
    
    [self performSegueWithIdentifier: @"profile" sender: self];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"detail"])
    {
        SecondViewController *destination = segue.destinationViewController;
        destination.insertTwit = twitText;
        destination.insertDate = twitDate;
        destination.insertUser = twitUser;
    }
    else if ([segue.identifier isEqualToString:@"profile"])
    {
        ThirdViewController *destination = segue.destinationViewController;
        destination.insertName = twitName;
        destination.insertUser = twitUser;
        destination.insertdetail = twitDetail;
        destination.insertFollowers = twitFollowed;
        destination.insertFriends = twitFriends;
        destination.insertImage = twitImage;
    }
}


@end
