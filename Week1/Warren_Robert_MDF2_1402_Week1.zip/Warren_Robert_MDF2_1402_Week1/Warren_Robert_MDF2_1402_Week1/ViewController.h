//
//  ViewController.h
//  Warren_Robert_MDF2_1402_Week1
//
//  Created by Robert Warren on 2/3/14.
//  Copyright (c) 2014 Robert Warren. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UITableView *tabled;
    NSArray *feeder;
    NSString *twitText;
    NSString *twitDate;
    NSString *twitUser;
    NSString *twitName;
    NSString *twitDetail;
    NSString *twitFollowed;
    NSString *twitFriends;
    UIImage *twitImage;
    UIActivityIndicatorView *indicator;
    UIAlertView *alert;
}

-(IBAction)poster:(id)sender;
-(IBAction)onRefresh:(id)sender;
-(IBAction)Prolific:(id)sender;

@end
